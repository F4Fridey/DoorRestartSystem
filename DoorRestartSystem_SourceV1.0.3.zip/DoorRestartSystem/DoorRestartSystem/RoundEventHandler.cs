﻿using System.Threading.Tasks;
using Smod2;
using Smod2.API;
using Smod2.Attributes;
using Smod2.Config;
using Smod2.EventHandlers;
using Smod2.Events;
using Smod2.Lang;
using Smod2.Piping;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

namespace DoorRestartSystem
{
    class RoundEventHandler : IEventHandlerRoundStart, IEventHandlerFixedUpdate, IEventHandlerWarheadStartCountdown, IEventHandlerWarheadStopCountdown, IEventHandlerRoundRestart
    {
        private readonly DoorRestartSystem plugin;
        private float countDown;
        private float timer;
        private bool restarted;
        private bool roundstarted;
        private bool countedDown;
        private bool dooreventstated;
        private bool doorsclosed;
        private bool doorsunlocked;
        private Door[] doorlist;
        

        public RoundEventHandler(DoorRestartSystem plugin)
        {
            this.plugin = plugin;

        }

        public void OnFixedUpdate(FixedUpdateEvent ev)
        {

            if (plugin.drenabled && roundstarted && !plugin.nukeOn)
            {
                if (!restarted)
                {
                    plugin.ticks += Time.deltaTime;
                    //plugin.Debug(ticks.ToString());
                }



                if (plugin.ticks > plugin.timetillrestart && !restarted)
                {
                    restarted = true;
                    PlayerManager.localPlayer.GetComponent<MTFRespawn>().CallRpcPlayCustomAnnouncement("WARNING . DOOR SOFTWARE REPAIR IN t minus 20 seconds .", false);
                    plugin.Debug("Begin the door event");

                }

                if (restarted)
                {
                    if (countDown < 26.0)
                    {
                        countDown += Time.deltaTime;
                        //plugin.Debug(countDown.ToString());
                    }
                    if (countDown > 21.0 && !countedDown)
                    {
                        countedDown = true;
                        PlayerManager.localPlayer.GetComponent<MTFRespawn>().CallRpcPlayCustomAnnouncement("3 . 2 . 1 .", false);
                    }
                    if (countDown >= 26.0 && !doorsunlocked)
                    {
                        if (timer == 0f && !doorsclosed)
                        {
                            doorsclosed = true;
                            plugin.Debug("doors closed");
                            plugin.Debug("doors locked");
                            doorlist = UnityEngine.Object.FindObjectsOfType<Door>();
                            for (int i = 0; i < doorlist.Length; i++)
                            {
                                doorlist[i].Networklocked = true;
                                doorlist[i].NetworkisOpen = false;
                                //plugin.Debug(doorlist[i].ToString());
                            }
                        }
                        if (!dooreventstated)
                        {
                            timer += Time.deltaTime;
                        }
                        if (timer > plugin.duration && !doorsunlocked)
                        {
                            doorsunlocked = true;
                            dooreventstated = true;
                            plugin.Debug("doors unlocked");
                            for (int i = 0; i < doorlist.Length; i++)
                            {
                                doorlist[i].Networklocked = false;
                                //plugin.Debug(doorlist[i].ToString());
                            }
                            PlayerManager.localPlayer.GetComponent<MTFRespawn>().CallRpcPlayCustomAnnouncement("DOOR SOFTWARE REPAIR COMPLETE", false);
                            if (plugin.repeatrestarts || plugin.calledcommand)
                            {
                                ReloadThings();
                            }
                        }
                    }
                }

            }
        }

        public void OnRoundStart(RoundStartEvent ev)
        {
            if (plugin.drenabled)
            {
                ReloadThings();
                plugin.Debug(plugin.timetillrestart.ToString());
            }
        }

        public void ReloadThings()
        {
            plugin.timetillrestart = Random.Range(plugin.drmintime, plugin.drmaxtime);
            restarted = false;
            plugin.ticks = 0f;
            countDown = 0f;
            timer = 0f;
            roundstarted = true;
            dooreventstated = false;
            countedDown = false;
            doorsclosed = false;
            doorsunlocked = false;
            plugin.calledcommand = false;
            plugin.nukeOn = false;
        }

        public void OnStartCountdown(WarheadStartEvent ev)
        {
            plugin.nukeOn = true;
        }

        public void OnStopCountdown(WarheadStopEvent ev)
        {
            plugin.nukeOn = false;
        }

        public void OnRoundRestart(RoundRestartEvent ev)
        {
            roundstarted = false;
            ReloadThings();
        }
    }
}
