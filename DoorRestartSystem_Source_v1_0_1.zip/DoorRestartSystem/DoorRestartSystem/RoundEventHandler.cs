﻿using System.Threading.Tasks;
using Smod2;
using Smod2.API;
using Smod2.Attributes;
using Smod2.Config;
using Smod2.EventHandlers;
using Smod2.Events;
using Smod2.Lang;
using Smod2.Piping;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

namespace DoorRestartSystem
{
    class RoundEventHandler : IEventHandlerRoundStart, IEventHandlerFixedUpdate, IEventHandlerWarheadStartCountdown, IEventHandlerWarheadStopCountdown
    {
        private readonly DoorRestartSystem plugin;
        private float ticks;
        private float countDown;
        private float timetillrestart;
        private float timer;
        private bool restarted;
        private bool roundstarted;
        private bool countedDown;
        private bool dooreventstated;
        private bool doorsclosed;
        private bool doorsunlocked;
        private Door[] doorlist;
        private bool nukeOn;

        public RoundEventHandler(DoorRestartSystem plugin)
        {
            this.plugin = plugin;

        }

        public void OnFixedUpdate(FixedUpdateEvent ev)
        {

            if (plugin.drenabled && roundstarted && !nukeOn)
            {
                if (!restarted)
                {
                    ticks += Time.deltaTime;
                    //plugin.Debug(ticks.ToString());
                }



                if (ticks > timetillrestart && !restarted)
                {
                    restarted = true;
                    PlayerManager.localPlayer.GetComponent<MTFRespawn>().CallRpcPlayCustomAnnouncement("WARNING . DOOR SOFTWARE REPAIR IN t minus 20 seconds .", false);
                    plugin.Debug("Begin the door event");

                }

                if (restarted)
                {
                    if (countDown < 26.0)
                    {
                        countDown += Time.deltaTime;
                        //plugin.Debug(countDown.ToString());
                    }
                    if (countDown > 21.0 && !countedDown)
                    {
                        countedDown = true;
                        PlayerManager.localPlayer.GetComponent<MTFRespawn>().CallRpcPlayCustomAnnouncement("3 . 2 . 1 .", false);
                    }
                    if (countDown >= 26.0 && !doorsunlocked)
                    {
                        if (timer == 0f && !doorsclosed)
                        {
                            doorsclosed = true;
                            plugin.Debug("doors closed");
                            plugin.Debug("doors locked");
                            doorlist = UnityEngine.Object.FindObjectsOfType<Door>();
                            for (int i = 0; i < doorlist.Length; i++)
                            {
                                doorlist[i].Networklocked = true;
                                doorlist[i].NetworkisOpen = false;
                                //plugin.Debug(doorlist[i].ToString());
                            }
                        }
                        if (!dooreventstated)
                        {
                            timer += Time.deltaTime;
                        }
                        if (timer > plugin.duration && !doorsunlocked)
                        {
                            doorsunlocked = true;
                            dooreventstated = true;
                            plugin.Debug("doors unlocked");
                            for (int i = 0; i < doorlist.Length; i++)
                            {
                                doorlist[i].Networklocked = false;
                                //plugin.Debug(doorlist[i].ToString());
                            }
                            PlayerManager.localPlayer.GetComponent<MTFRespawn>().CallRpcPlayCustomAnnouncement("DOOR SOFTWARE REPAIR COMPLETE", false);
                            if (plugin.repeatrestarts)
                            {
                                ReloadThings();
                            }
                        }
                    }
                }

            }
        }

        public void OnRoundStart(RoundStartEvent ev)
        {
            if (plugin.drenabled)
            {
                ReloadThings();
                plugin.Debug(timetillrestart.ToString());
                nukeOn = false;
            }
        }

        public void ReloadThings()
        {
            timetillrestart = Random.Range(plugin.drmintime, plugin.drmaxtime);
            restarted = false;
            ticks = 0f;
            countDown = 0f;
            timer = 0f;
            roundstarted = true;
            dooreventstated = false;
            countedDown = false;
            doorsclosed = false;
            doorsunlocked = false;
        }

        public void OnStartCountdown(WarheadStartEvent ev)
        {
            nukeOn = true;
        }

        public void OnStopCountdown(WarheadStopEvent ev)
        {
            nukeOn = false;
        }
    }
}
