﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Smod2;
using Smod2.API;
using Smod2.Attributes;
using Smod2.Config;
using Smod2.EventHandlers;
using Smod2.Events;
using Smod2.Lang;
using Smod2.Piping;

namespace DoorRestartSystem
{
    [PluginDetails(
        author = "F4Fridey",
        name = "DoorRestartSystem",
        description = "Interesting door event.",
        id = "f4fridey.doorrestartsystem.plugin",
        configPrefix = "drs",
        langFile = "doorrestartsystem",
        version = "1.0.3",
        SmodMajor = 3,
        SmodMinor = 4,
        SmodRevision = 1
        )]
    public class DoorRestartSystem : Plugin
    {
        [ConfigOption("door_restart_enabled")]
        public readonly bool drenabled = true;

        [ConfigOption("door_restart_min")]
        public readonly float drmintime = 300;

        [ConfigOption("door_restart_max")]
        public readonly float drmaxtime = 360;

        [ConfigOption("repeat_restarts")]
        public readonly bool repeatrestarts = false;

        [ConfigOption("lockdown_duration")]
        public readonly float duration = 10;

        public float ticks;
        public float timetillrestart;
        public bool calledcommand;
        public bool nukeOn;

        public override void Register()
        {
            this.AddEventHandlers(new RoundEventHandler(this));
            this.AddCommand("RESTARTDOORS", new CommandHandler(this));
            calledcommand = false;
        }

        public override void OnEnable()
        {
            if (drenabled)
            {
                this.Info("Door Restart System version 1.0.3 loaded. :)");
            } else
            {
                this.Info("Door Restart System. Error: Not enabled in config.");
            }
            
        }

        public override void OnDisable()
        {
            this.Info("Door Restart System not loaded. Error: Unknown.");
        }
    }
}
