﻿using Smod2;
using Smod2.Commands;
using Smod2.API;
using Smod2.EventHandlers;
using Smod2.Events;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using Random = UnityEngine.Random;

namespace DoorRestartSystem
{
    class CommandHandler : ICommandHandler
    {
        private readonly DoorRestartSystem plugin;

        public CommandHandler(DoorRestartSystem plugin)
        {
            this.plugin = plugin;
        }

        public string GetCommandDescription()
        {
            return "Starts the door restart system.";
        }

        public string GetUsage()
        {
            return "RESTARTDOORS";
        }

        public string[] OnCall(ICommandSender sender, string[] args)
        {
            if (plugin.drenabled == true)
            {
                if (plugin.ticks < plugin.timetillrestart && !plugin.nukeOn)
                {
                    plugin.ticks = plugin.timetillrestart + 1;
                    plugin.calledcommand = true;
                    return new string[]
                    {
                    "Beginning door software restart event."
                    };
                }
                else
                {
                    return new string[]
                {
                    "Error: DSR event has already begun or nuke has been engaged."
                };
                }
                
            }
            else
            {
                return new string[]
                {
                    "Error: Door Software Restart plugin disabled."
                };
            }

        }
    }
}
